////
////  pseudocode.cpp
////  Project2
////
////  Created by Tiya Chokhani on 1/31/23.
////
//
//insert
//if contains value return false
//if the set is empty
//    create a new node and set both its pointers to nullptr
//    set head and tail to the new Node
//    incr the size
//if the value is smaller than the first value in the set
//    add it as the first node
//    set the head pointer to the new node
//if the value is being added to the end of the list
//    create a new node and set the tail to it
//for all the nodes
//    if any Node value is greater than value set p to it
//        create a new node
//        set p to the previous node
//        if p isnt the tail
//            set the new nodes pointers
//        else
//            set the tail to newnode
//        add size
//
//erase
//if contains value
//    if the first node contains the value
//        if only one value exists
//            delete the node
//            set head and tail to nullptr
//        create a new pointer to point to the node that needs to be deleted
//        set head to the next node
//        and the next nodes prev pointer to nullptr
//        delete the node
//    for all the nodes
//        if any contains the value set p to it
//            move p back by one node
//            create a temp pointer and assign it to the node that needs to be deleted
//            if the node thats going to be deleted is the last node
//                set tail to the prev node
//            delete the node
//
//get
//if the position is out of bounds return false
//create a int counter
//create a pointer to go through all the values
//go through values till either the node is over or the counter has reched the position
//set p to point to the node thats exactly graeter than pos items
//return the value that p points to
//
//swap
//create a temp pointer set it to head
//set head to other head
//set other head to temp
//
//set temp to tail
//set tail to other tail
//set other tail to temp
//
//~Set
//create a new pointer
//while the pointer isnt pointing to a nullptr
//    create a temp pointer that points to the same node as p
//    set p to point to the next node
//    delete the node the temp pointer points to
//set head and tail to nullptr
//
//copy constructor
//initialise size as the other size and head and tail as nullptr
//for all the nodes in the other set
//    insert them in the set
//
//assignment operator
//check that the sets arent the same
//create a temp set thats the same as the rhs
//swap the temp set
//return the pointer to the set
//
//unite
//create a itemtype value
//create a temp set thats the same as s1
//for the size of s2
//    get s2s values
//    inset them in the temp set
//swap the temp set with result
//
//butNot
//create a itemtype value
//create a temp set thats the same as s1
//for the size of s2
//    get s2s values
//    erase the value from the temp set
//swap the temp set and result
//
//
//            
//
//


//#include <iostream>
//#include <cassert>
//#include "Set.h"
//#include <string>
//using namespace std;
//
//void test()
//{
//    Set ss; //constructor
//    // For an empty set:
//    assert(ss.size() == 0);        // test size
//    assert(ss.empty());            // test empty
//    assert(!ss.erase("roti"));     // nothing to remove
//
//    assert(ss.insert("roti")); //insert first item
//    assert(ss.insert("pita")); //insert an item smaller than first item in set
//    assert(ss.size() == 2); //check size
//    assert(ss.insert("a")); //insert an item smaller than first item in set
//    assert(ss.insert("zzzzz"));//insert an item at the end of the end
//    assert(ss.contains("pita") && ss.contains("a") && ss.contains("roti") && ss.contains("zzzzz")); //check contains all the values
//    assert(ss.size() == 4); //check size again
//    assert(ss.insert("b")); //insert in the middle
//    ItemType x = "laobing";
//    assert(ss.get(0, x) &&  x == "a"); //check get for first item
//    assert(ss.get(1, x) &&  x == "b"); //get for middle item
//    assert(ss.get(2, x) &&  x == "pita"); //chekc get for middle item
//    assert(ss.get(4, x)  &&  x == "zzzzz"); //check get for last item
//    assert(!ss.get(7, x)  &&  x == "zzzzz"); //check get for an item out of range
//    assert(ss.erase("a")); //erase the first item
//    assert(ss.erase("zzzzz")); //erase the last item
//    assert(ss.size() == 3); //check size after erasing
//    assert(ss.erase("pita")); //erase an ite from the middle
//    assert(ss.size() == 2); //check size to make sure its been erased
//    assert(ss.get(0, x)  &&  x == "b"); //check new set
//    Set m(ss); //copy constructor
//    assert(m.get(0, x)  &&  x == "b");  //check m
//    assert(m.size() == 2); //check m has the right size
//    assert(m.contains("b") && m.contains("roti")); //check m contains all the items
//    Set m1 = ss; //assignment operator
//    assert(m1.get(0, x)  &&  x == "b");  //check m
//    assert(m1.size() == 2); //check m has the right size
//    assert(m1.insert("a")); //see if you can insert
//    assert(m1.contains("b") && m1.contains("roti") && m1.contains("a")); //check m contains all the items
//    assert(m1.erase("roti"));
//    assert(m1.insert("nnn"));
//    m1.swap(m);
//    assert(m.contains("b") && m.contains("a") && m.contains("nnn") && m.size() == 3); //check that swap works properly
//    assert(m1.contains("b") && m1.contains("roti") && m1.size() == 2);
//    Set n;
//    unite(m, m1, n);
//    assert(n.contains("roti") && n.contains("b") && n.contains("a") && n.contains("nnn") && n.size() == 4); //check that unite works
//    butNot(m, m1, n);
//    assert(n.contains("a") && n.contains("nnn") && n.size() == 2); //check that butNot works
//}
//
//int main()
//{
//    test();
//    cout << "Passed all tests" << endl;
//}

#include "Set.h"
#include <type_traits>

#define CHECKTYPE(c, f, r, a)  \
{  \
 static_assert(std::is_same<decltype(&c::f), r (c::*)a>::value, \
     "You did not declare " #c "::" #f " as the Project 2 spec does");  \
 auto p = static_cast<r (c::*)a>(&c::f);  \
 (void) p;  \
}
#define CHECKTYPENONMEMBER(f, r, a)  \
{  \
 static_assert(std::is_same<decltype(&f), r (*)a>::value, \
     "You did not declare " #f " as the Project 2 spec does");  \
 auto p = static_cast<r (*)a>(f);  \
 (void) p;  \
}

static_assert(std::is_default_constructible<Set>::value,
        "Set must be default-constructible.");
static_assert(std::is_copy_constructible<Set>::value,
        "Set must be copy-constructible.");
static_assert(std::is_copy_assignable<Set>::value,
        "Set must be assignable.");

void thisFunctionWillNeverBeCalled()
{
    CHECKTYPE(Set, empty,     bool, () const);
    CHECKTYPE(Set, size,      int,  () const);
    CHECKTYPE(Set, insert,    bool, (const ItemType&));
    CHECKTYPE(Set, erase,     bool, (const ItemType&));
    CHECKTYPE(Set, contains,  bool, (const ItemType&) const);
    CHECKTYPE(Set, get,       bool, (int, ItemType&) const);
    CHECKTYPE(Set, swap,      void, (Set&));
    CHECKTYPENONMEMBER(unite,  void, (const Set&, const Set&, Set&));
    CHECKTYPENONMEMBER(butNot, void, (const Set&, const Set&, Set&));
}

int main()
{}
