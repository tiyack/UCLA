//
//  main.cpp
//  Project2
//
//  Created by Tiya Chokhani on 1/30/23.
//

#include <iostream>
#include "Set.h"
using namespace std;


Set::Set(){
    m_size = 0; //intialise a new set
    head = nullptr;
    tail = nullptr;
}

bool Set::empty() const {
    return (head == nullptr && tail == nullptr && m_size == 0);
}

int Set::size() const {
    return m_size;
}

bool Set::insert(const ItemType& value) {
    if(contains(value)) //if value exists doesnt add
        return false;
    if(head == nullptr){ //if the first item in being added
        Node* newNode = new Node;
        newNode->data = value;
        newNode->next = nullptr;
        newNode->prev = nullptr;
        head = newNode;
        tail = newNode;
        m_size++; //incr size
        return true;
    }
    if(head->data > value){ //if the value being added is smaller than the first value
        Node* newNode = new Node;
        newNode->data = value;
        newNode->next = head;
        newNode->prev = head->prev;
        head->prev = newNode;
        head = newNode;
        m_size++;
        return true;
    }
    if(value > tail->data){ //if the value being added is greater than the last value
        Node* newNode = new Node;
        newNode->data = value;
        newNode-> next = tail->next;
        newNode->prev = tail;
        tail->next = newNode;
        tail = newNode;
        m_size++;
        return true;
    }
    Node* p;
    for(p = head; p != nullptr; p = p->next){
        if(p->data > value){ //if value added is in the middle
            Node* newNode = new Node;
            newNode->data = value;
//            if(p->prev == nullptr){ //makes sure that p's prev isnt a null
//                newNode->next = p->next;
//                newNode->prev = p;
//                p->next->prev = newNode;
//                p->next = newNode;
//                m_size++;
//                return true;
//            }
            p = p->prev; //sets p to the node smaller than value
            newNode->next = p->next;
            if(p != tail){ //makes sure p isnt the tail
                newNode->prev = p->next->prev;
                newNode->next->prev = newNode;
            }
            else{
                newNode->prev = p;
                tail = newNode;
            }
            p->next = newNode;
            m_size++;
            return true;
        }
    }
    return false;
}

bool Set::erase(const ItemType& value){
    if(contains(value)){ //if value exists
        if(head->data == value){ //if value is the first
            if(head->next == nullptr){ //if only one value exists
                delete head; //delete value
                head = nullptr;
                tail = nullptr;
                m_size--;
                return true;
            }
            Node* tbd = head;
            head = head->next;
            head->prev = nullptr;
            delete tbd;
            m_size--;
            return true;
        }
        Node* p;
        for(p = head; p != nullptr; p = p->next){
            if(p->data == value){ //find value
                p = p->prev;
                Node* tbd = p->next;
                p->next = tbd->next;
                if(tbd == tail){ //makes sure its not the tail
                    tail = tbd->prev;
                }
                delete tbd;
                m_size--;
                return true;
            }
        }
    }
    return false;
}

bool Set::contains(const ItemType& value) const {
    Node* p;
    for(p = head; p != nullptr; p = p->next){
        if((*p).data == value) //checks if value exists in set
            return true;
    }
    return false;
}

bool Set::get(int pos, ItemType& value) const {
    if(pos < 0 || pos >= m_size)
        return false;
    int i = 0;
    Node* p;
    for(p = head; p != nullptr && i < pos; p = p->next){
        i++;
    }
    value = p->data;
    return true;
}

void Set::swap(Set& other){
    Node* temp = head;
    head = other.head;
    other.head = temp;
    
    temp = tail;
    tail = other.tail;
    other.tail = temp;
    
    int temp1 = m_size;
    m_size = other.m_size;
    other.m_size = temp1;
}

Set::~Set(){
    Node* p = head;
    while(p != nullptr){
        Node* tbd = p;
        p = p->next;
        delete tbd;
    }
    head = nullptr;
    tail = nullptr;
}

Set::Set(const Set& other)
:head(nullptr), tail(nullptr){
    m_size = 0;
    Node* p;
    for(p = other.head; p!= nullptr; p = p->next){
        insert(p->data);
    }
}

Set& Set::operator=(const Set& rhs){
    if (this != &rhs)
    {
        Set temp(rhs);
        swap(temp);
    }
    return *this;
}

void unite(const Set& s1, const Set& s2, Set& result){
    ItemType value;
    Set temp(s1);                   //duplicates set s1
    int size = s2.size();
    for(int k = 0; k < size; k++){
        s2.get(k, value);           //get all values in s2
        temp.insert(value);       //adds unique values to temp
    }
    result.swap(temp);          //update results with new set
}


void butNot(const Set& s1, const Set& s2, Set& result){
    ItemType value;
    Set temp(s1);                    //copy set s1
    int size = s2.size();
    for(int k = 0; k < size; k++){
        s2.get(k, value);           //get all values in s2
        temp.erase(value);          //erase duplicate values in result
    }
    result.swap(temp);              //update results with new set
}


