To run PeachParty:

1. Locate the folder PeachParty, which should have in it files named
PeachParty and Assets.  It's likely that the path to the folder will be
/Users/yourname/PeachParty or /Users/yourname/Downloads/PeachParty.

2. Open a Terminal window and type
        cd whateverThePathIs
where you should replace whateverThePathIs with the path to the
PeachParty folder.

3. Confirm you're in the right folder by typing
        ls
which should show you the Assets folder and the PeachParty executable.

4. Type
        ./PeachParty
to play the game.

Alternatively, in the folder PeachParty, you can move the Assets folder
to your home directory, then double-click on the PeachParty executable
file.
