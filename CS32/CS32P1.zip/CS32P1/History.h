//
//  History.hpp
//  CS32P1
//
//  Created by Tiya Chokhani on 1/13/23.
//

#ifndef History_hpp
#define History_hpp

#include "globals.h"

class History
{
  public:
    History(int nRows, int nCols);
    bool record(int r, int c);
    void display() const;
    
  private:
    int m_grid[MAXROWS][MAXCOLS];
    int m_rows;
    int m_cols;
    
};

#endif /* History_hpp */
