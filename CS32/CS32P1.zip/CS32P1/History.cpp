//
//  History.cpp
//  CS32P1
//
//  Created by Tiya Chokhani on 1/13/23.
//

#include "History.h"
#include <iostream>
#include "globals.h"
using namespace std;

History::History(int nRows, int nCols){
    m_rows = nRows;
    m_cols = nCols;
    for (int r = 1; r <= m_rows; r++)
        for (int c = 1; c <= m_cols; c++)
            m_grid[r][c] = 0;
}

bool History::record(int r, int c){
    if (r < 1  ||  r > m_rows  ||  c < 1  ||  c > m_cols)
    {
        return false;
    }
    if (m_grid[r][c] == 0)
        m_grid[r][c] = 1;
    else if (m_grid[r][c] < 26){
        m_grid[r][c] += 1;
    }
    return true;
}

void History::display() const{
    clearScreen();
    for (int r = 1; r <= m_rows; r++){
        for (int c = 1; c <= m_cols; c++){
            if (m_grid[r][c] == 0)
                cout << ".";
            else {
                char a = 'A';
                
                a = a + m_grid[r][c] - 1;
                cout << a;
            }
        }
        cout << endl;
    }
    cout << endl;
}
