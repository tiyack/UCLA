// rabbits.cpp

////#include "History.h"
//#include "Game.h"
////using namespace std;
//
//int main()
//{
////    History h(10,10);
////    for (int i = 0; i < 30; i++)
////        h.record(1, 1);
////    for (int i = 0; i < 27; i++)
////        h.record(5, 1);
////    for (int i = 0; i < 26; i++)
////        h.record(1, 2);
////    h.record(0, 7);
////    h.display();
////
//
//      // Create a game
//      // Use this instead to create a mini-game:   Game g(3, 5, 2);
//    Game g(10, 12, 40);
//
//      // Play the game
//    g.play();
//}

//#include "Game.h"
//    #include "Game.h"
//    #include "Arena.h"
//    #include "Arena.h"
//    #include "History.h"
//    #include "History.h"
//    #include "Player.h"
//    #include "Player.h"
//    #include "Rabbit.h"
//    #include "Rabbit.h"
//    #include "globals.h"
//    #include "globals.h"
//    int main()
//    {}

//#include "History.h"
//    int main()
//    {
//        History h(2, 2);
//        h.record(1, 1);
//        h.display();
//    }

//#include "Rabbit.h"
//    int main()
//    {
//        Rabbit r(nullptr, 1, 1);
//    }

//#include "Player.h"
//    int main()
//    {
//        Player p(nullptr, 1, 1);
//    }

//#include "Arena.h"
//int main()
//{
//    Arena a(10, 18);
//    a.addPlayer(2, 2);
//}

//#include "globals.h"
//#include "Player.h"
//#include "Arena.h"
//int main()
//{
//    Arena a(10, 20);
//    Player p(&a, 2, 3);
//}

//#include "Arena.h"
//#include "Player.h"
//int main()
//{
//    Arena a(10, 20);
//    Player p(&a, 2, 3);
//}

//#include "Player.h"
//#include "Arena.h"
//int main()
//{
//    Arena a(10, 20);
//    Player p(&a, 2, 3);
//}

//#include "History.h"
//#include "Arena.h"
//#include <iostream>
//using namespace std;
//
//int main()
//{
//    Arena a(1, 3);
//    a.history().record(1, 2);
//    Arena a2(1, 2);
//    a2.history().record(1, 1);
//    a.history().display();
//    cout << "===" << endl;
//}

#include "Arena.h"
#include "Player.h"
#include "History.h"
#include "globals.h"
#include <iostream>
using namespace std;

int main()
{
    Arena a(1, 4);
    a.addPlayer(1, 2);
    a.player()->dropPoisonedCarrot();
    a.player()->dropPoisonedCarrot();
    a.player()->move(EAST);
    a.player()->dropPoisonedCarrot();
    a.player()->move(EAST);
    a.addRabbit(1, 1);
    while (a.rabbitCount() > 0)
        a.moveRabbits();
    a.player()->move(WEST);
    a.player()->dropPoisonedCarrot();
    a.history().display();
    cout << "====" << endl;
}

//NOT COMPLIE
//#include "Rabbit.h"
//#include "Arena.h"
//int main()
//{
//    Arena a(10, 20);
//    Player p(&a, 2, 3);
//    Rabbit r(&a, 1, 1);
//}

//#include "Player.h"
//#include "Arena.h"
//int main()
//{
//    Arena a(10, 20);
//    Player p(&a, 2, 3);
//    Rabbit r(&a, 1, 1);
//}

//#include "globals.h"
//#include "Rabbit.h"
//#include "Player.h"
//int main()
//{
//    Arena a(10, 10);
//}

//#include "Game.h"
//int main()
//{
//    Arena a(10, 10);
//}

//#include "History.h"
//int main()
//{
//    History h;
//}
