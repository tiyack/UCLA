//
//  main.cpp
//  Project 4
//
//  Created by Tiya Chokhani on 10/30/22.
#include <iostream>
#include <string>
#include <cctype>
#include <cassert>
using namespace std;

int appendToAll(string a[], int n, string value){
    if (n < 0) //need to return -1 for negative n
        return -1;
    for (int i = 0; i < n; i++){
        a[i] = a[i] + value;
    }
    return n;
}

int lookup(const string a[], int n, string target){
    if (n < 0)
        return -1;
    for (int i = 0; i < n; i++){
        if(a[i] == target)
            return i;
    }
    return -1; //if nothing matches return -1
}

int positionOfMax(const string a[], int n){
    if (n <= 0)     //if 0 elements then need to return -1
        return -1;
    string max = a[0];
    int maxCount = 0; //position of max in array
    for (int i = 0; i < n; i++){
        if (a[i] > max){
            max = a[i];
            maxCount = i;
        }
    }
    return maxCount;
}

int rotateLeft(string a[], int n, int pos){
    if (n <= 0 || pos < 0 || pos > (n - 1))
        return -1;
    string temp = a[pos]; //storing the string at position 'pos'
    for(int i = pos; i < n - 1; i++){
        a[i] = a[i+1]; //shifting everything after pos to the left
    }
    a[n - 1] = temp; //setting last position of the array
    return pos;
}

int countRuns(const string a[], int n){
    if (n < 0)
        return -1;
    if (n == 0)
        return 0;
    if (n == 1)
        return 1;
    //n >= 2
    int counter = 0;
    for (int i = 0; i < n - 1; i++){
        while(a[i] == a[i + 1]){ //count for all the consecutive identical items in the aray
            counter++;
            if((i + 1) < (n - 1))//to make sure while doesnt try to access an index that doesnt exist
                i++;
            else
                break;
        }
    }
    return (n - counter); //subtract the count from total items in the array
}

int flip(string a[], int n){
    if (n < 0)
        return -1;
    string temp;
    for (int i = 0; i < (n / 2); ++i) {
        temp = a[i];             // Temp for swap
        a[i] = a[n - 1 - i];     // First part of swap
        a[n - 1 - i] = temp;     // Second complete
    }
    return n;
}

int differ(const string a1[], int n1, const string a2[], int n2){
    if (n1 < 0 || n2 < 0)
        return -1;
    if (n1 > n2){
        for (int i = 0; i < n2; i++){
            if (a1[i] != a2[i])
                return i;
        }
        return n2; //returns the smaller number from n1 & n2
    }
    else{
        for (int i = 0; i < n1; i++){
            if (a1[i] != a2[i])
                return i;
        }
        return n1; //returns the smaller number from n1 & n2
    }
}

int subsequence(const string a1[], int n1, const string a2[], int n2){
    if (n1 < 0 || n2 < 0)
        return -1;
    if ((n1 && n2) == 0)
        return 0;
    for (int i = 0; i < n1; i++){
        if (a1[i] == a2[0]){ //find position of a2[0] is in a1
        //now we need to check that corresponding elements of a1 and a2 are completely equal
            bool check = true;
            for (int j = 0; j < n2; j++){
                if ((i + n2) > n1) //to prevent undefined program behavior
                    return -1;
                if (a1[j + i] != a2[j]){
                    check = false;
                    break; //this is not the right sequence
                }
            } //breaks here
            if (check)
                return i;
        }
    }
    return -1;
}

int lookupAny(const string a1[], int n1, const string a2[], int n2){
    if (n1 < 0 || n2 < 0)
        return -1;
    for (int i = 0; i < n1; i++){ //to check all elements of a1
        for (int k = 0; k < n2; k++){ //to check all elements of a2
            if (a1[i] == a2[k])
                return i;
        }
    }
    return -1;
}

int split(string a[], int n, string splitter){
    if (n < 0)
        return -1;
    string temp;
    for (int i = 0; i < n; i++){
        for (int j = i + 1; j < n; j++){
            if (a[i] > a[j]){ //if next string in array is smaller then swap positions
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
        //cerr << a[i] << " ";
    } //basically sorts the entire array
    //cerr << endl;
    for (int i = 0; i < n; i++){
        if (a[i] >= splitter) //find index thats equal or greater than splitter
            return i;
    }
    return n;
}

int main() {
    
//rotateLeft, split, flip, append
  //  lookup
    string people1[6] = { "boris", "gordon", "rishi", "liz", "john", "john" };
    assert(lookup(people1, 5, "gordon") == 1); //valid
    assert(lookup(people1, 1, "rishi") == -1); //checks that function only checks till n
    assert(lookup(people1, 5, "ris") == -1); //not in list
    assert(lookup(people1, -3, "go") == -1); //negative num
    assert(lookup(people1, 6, "john") == 4); //if repeated needs to return smaller num

    string h[7] = { "rishi", "margaret", "gordon", "tony", "", "john", "liz" };
    assert(lookup(h, 7, "john") == 5);
    assert(lookup(h, 7, "gordon") == 2);
    assert(lookup(h, 2, "gordon") == -1);
    assert(positionOfMax(h, 7) == 3);

    //position of Max
    string pp2[6] = { "david", "liz", "margaret", "tony", "gordon", "boris" };
    assert(positionOfMax(pp2, 6) == 3); //valid

    string pp1[6] = { "tony", "liz", "margaret", "tony", "gordon", "boris" };
    assert(positionOfMax(pp1, 6) == 0);//to check that it returns smallest if same
    assert(positionOfMax(pp1, 0) == -1); //checks to see returns -1 if number of items is 0
    assert(positionOfMax(pp1, -10) == -1);//when negative
    assert(positionOfMax(pp1, 1) == 0); //checks to see returns position even if only one element is there

    //rotate left
    string mp[5] = { "john", "david", "liz", "theresa", "margaret" };
    assert((rotateLeft(mp, 5, 1) == 1) && mp[2] == "theresa" && mp[4] == "david");//valid

    string mp1[5] = { "john", "david", "liz", "theresa", "margaret" };
    assert((rotateLeft(mp1, 2, 1) == 1) && mp1[0] == "john"); //checks that it only considers n items

    string mp2[5] = { "john", "david", "liz", "theresa", "margaret" };
    assert((rotateLeft(mp2, 5, 4) == 4) && mp2[2] == "liz");//rotate last item to array is unchanged
    assert((rotateLeft(mp2, 5, 0) == 0) && mp2[4] == "john" && mp2[0] == "david");//when first index
    assert(rotateLeft(mp2, -2, 0) == -1);//when negative num
    assert(rotateLeft(mp2, 5, -4) == -1);//when pos negative
    assert(rotateLeft(mp2, 5, 5) == -1);//when pos doesnt exist in array

    //reverse
    string leader[6] = { "boris", "rishi", "", "tony", "theresa", "david" };
    assert((flip(leader, 4) == 4) && leader[0] == "tony" && leader[5] == "david"); //only for n items
    assert((flip(leader, 0) == 0) && leader[0] == "tony"); //for 0
    assert(flip(leader, -4) == -1); //negative num


    //differ
    string leader1[6] = { "boris", "rishi", "", "tony", "theresa", "david" };
    string politician[5] = { "boris", "rishi", "david", "", "tony" };
    assert(differ(leader1, 6, politician, 5) == 2);  //valid
    assert(differ(leader1, 2, politician, 1) == 1);  // check for n1 and n2
    assert(differ(leader1, -2, politician, 1) == -1);  //negative n1
    assert(differ(leader1, 0, politician, 1) == 0);  //n1 < n2
    assert(differ(leader1, 2, politician, 5) == 2);  //n1 > n2


    //lookany
    string namess[10] = { "john", "margaret", "theresa", "rishi", "boris", "liz" };
    string set1[10] = { "david", "boris", "rishi", "margaret" };
    assert(lookupAny(namess, 6, set1, 4) == 1);  // valid
    string set2[10] = { "tony", "gordon" };
    assert(lookupAny(namess, 6, set2, 2) == -1);  // no matches
    string set3[10] = { "boris", "liz" };
    assert(lookupAny(namess, 6, set3, 2) == 4);  //2 names match
    string namess1[10] = { "john", "john", "theresa", "john", "boris", "liz" };
    string set4[10] = { "john", "john" };
    assert(lookupAny(namess1, 6, set4, 2) == 0);  //multiple same matches
    assert(lookupAny(namess1, -5, set4, 0) == -1);  //negative n1
    assert(lookupAny(namess1, 2, set4, -5) == -1);  //negative n2
    assert(lookupAny(namess1, 5, set4, 0) == -1);//n2 0

    //appendToAll
    string people[5] = { "boris", "gordon", "rishi", "liz", "john" };
    assert(appendToAll(people, 5, "!!!") == 5 && people[0] == "boris!!!" && people[4] == "john!!!"); //adds !!! to all elements
    assert(appendToAll(people, -5, "!!!") == -1); //for negative num
    assert(appendToAll(people, 0, "!!!") == 0 && people[0] == "boris!!!" && people[4] == "john!!!"); //when num of elements is 0
    assert(appendToAll(people, 1, "?") == 1 && people[0] == "boris!!!?" && people[4] == "john!!!"); //appends only n number of items

    string g[4] = { "rishi", "margaret", "liz", "theresa" };
    assert(differ(h, 4, g, 4) == 2);
    assert(appendToAll(g, 4, "?") == 4 && g[0] == "rishi?" && g[3] == "theresa?");
    assert(rotateLeft(g, 4, 1) == 1 && g[1] == "liz?" && g[3] == "margaret?");

    string e[4] = { "gordon", "tony", "", "john" };
    assert(subsequence(h, 7, e, 4) == 2);//valid
    assert(subsequence(h, -3, e, 4) == -1);//negative n1
    assert(subsequence(h, 7, e, -5) == -1);//negative n2

    string names[10] = { "john", "margaret", "theresa", "rishi", "boris", "liz", "john", "margaret" };
    string names1[10] = { "margaret", "theresa", "rishi" };
    assert(subsequence(names, 6, names1, 3) == 1); //valid

    string names2[10] = { "boris", "liz", "rishi" };
    assert(subsequence(names, 6, names2, 3) == -1); //not all elements are repeated

    string names3[10] = { "john", "rishi" };
    assert(subsequence(names, 5, names3, 2) == -1); //names arent in the right order in a1
    string names4[10] = { "john", "margaret" };
    assert(subsequence(names, 8, names4, 2) == 0); //subsequence appears more than once
    assert(subsequence(names, 0, names4, 0) == 0);
    
    //countRuns
    string d[5] = { "margaret", "margaret", "margaret", "tony", "tony" };
    assert(countRuns(d, 5) == 2); //valid

    string d1[9] = {
        "tony", "tony", "rishi", "rishi", "gordon", "gordon", "gordon", "rishi", "tony"
    };
    assert(countRuns(d1, 9) == 5); //checks for repeated words non sequentially
    assert(countRuns(d1, 2) == 1); //only one run
    assert(countRuns(d1, 3) == 2); //2 runs
    assert(countRuns(d1, -8) == -1); //negative num
    assert(countRuns(d1, 0) == 0); //for 0
    assert(countRuns(d1, 1) == 1); //for n as 1

    string d2[9] = {
        "tony", "boris", "rishi", " ", " ", "gordon", "gordon", "rishi", "-"
    };
    assert(countRuns(d2, 9) == 7); // to check for space and non alplabets

    string f1[3] = { "liz", "liz"};
    assert(countRuns(f1, 2) == 1); // to

    string f[3] = { "liz", "gordon", "tony" };
    assert(lookupAny(h, 7, f, 3) == 2);
    assert(flip(f, 3) == 3 && f[0] == "tony" && f[2] == "liz");

    //split
    assert(split(h, 7, "liz") == 3);

    string pm[6] = { "david", "liz", "margaret", "tony", "gordon", "boris" };
    assert(split(pm, 6, "john") == 3); //when string isnt in the array

    string pm2[4] = { "margaret", "theresa", "liz", "rishi" };
    assert(split(pm2, 4, "rishi") == 2);  //string in the last item in the array

    string pm3[10] = { "f", "b", "b", "a", "e", "aa", "p", "k", "g", "d" };
    assert(split(pm3, 10, "z") == 10);  //no larger item exists in the array

    string pm4[10] = { "f", "b", "b", "a", "e", "aa", "p", "k", "g", "d" };
    assert(split(pm4, 6, "a") == 0);  //splitter is the smallest item in the array

    string pm5[10] = { "f", "b", "b", "a", "e", "aa", "p", "k", "g", "d" };
    assert(split(pm5, 2, "p") == 2);  //splitter is in the array
    assert(split(pm5, -4, "p") == -1); //negative num
    assert(split(pm5, 0, "p") == 0); //n is 0

    cerr << "All tests succeeded" << endl;
    //cerr << "Succeded!" << endl;
    //cerr << "Succeded!" << endl;
    return 0;
}
